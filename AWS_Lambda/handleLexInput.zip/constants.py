### Constants
AVAILABLE_RESOURCES = ("EC2", "DynamoDB", "S3")
EC2_LIFECYCLE = ("StopInstance", "TerminateInstance", "StartInstance", "RebootInstance")
